/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RC0 aliases
#define WLED_TRIS                 TRISCbits.TRISC0
#define WLED_LAT                  LATCbits.LATC0
#define WLED_PORT                 PORTCbits.RC0
#define WLED_WPU                  WPUCbits.WPUC0
#define WLED_OD                   ODCONCbits.ODCC0
#define WLED_ANS                  ANSELCbits.ANSELC0
#define WLED_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define WLED_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define WLED_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define WLED_GetValue()           PORTCbits.RC0
#define WLED_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define WLED_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define WLED_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define WLED_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define WLED_SetPushPull()        do { ODCONCbits.ODCC0 = 0; } while(0)
#define WLED_SetOpenDrain()       do { ODCONCbits.ODCC0 = 1; } while(0)
#define WLED_SetAnalogMode()      do { ANSELCbits.ANSELC0 = 1; } while(0)
#define WLED_SetDigitalMode()     do { ANSELCbits.ANSELC0 = 0; } while(0)

// get/set RC1 aliases
#define GLED_TRIS                 TRISCbits.TRISC1
#define GLED_LAT                  LATCbits.LATC1
#define GLED_PORT                 PORTCbits.RC1
#define GLED_WPU                  WPUCbits.WPUC1
#define GLED_OD                   ODCONCbits.ODCC1
#define GLED_ANS                  ANSELCbits.ANSELC1
#define GLED_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define GLED_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define GLED_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define GLED_GetValue()           PORTCbits.RC1
#define GLED_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define GLED_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define GLED_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define GLED_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define GLED_SetPushPull()        do { ODCONCbits.ODCC1 = 0; } while(0)
#define GLED_SetOpenDrain()       do { ODCONCbits.ODCC1 = 1; } while(0)
#define GLED_SetAnalogMode()      do { ANSELCbits.ANSELC1 = 1; } while(0)
#define GLED_SetDigitalMode()     do { ANSELCbits.ANSELC1 = 0; } while(0)

// get/set RC2 aliases
#define RLED_TRIS                 TRISCbits.TRISC2
#define RLED_LAT                  LATCbits.LATC2
#define RLED_PORT                 PORTCbits.RC2
#define RLED_WPU                  WPUCbits.WPUC2
#define RLED_OD                   ODCONCbits.ODCC2
#define RLED_ANS                  ANSELCbits.ANSELC2
#define RLED_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define RLED_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define RLED_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define RLED_GetValue()           PORTCbits.RC2
#define RLED_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define RLED_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define RLED_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define RLED_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define RLED_SetPushPull()        do { ODCONCbits.ODCC2 = 0; } while(0)
#define RLED_SetOpenDrain()       do { ODCONCbits.ODCC2 = 1; } while(0)
#define RLED_SetAnalogMode()      do { ANSELCbits.ANSELC2 = 1; } while(0)
#define RLED_SetDigitalMode()     do { ANSELCbits.ANSELC2 = 0; } while(0)

// get/set RC3 aliases
#define SCL_TRIS                 TRISCbits.TRISC3
#define SCL_LAT                  LATCbits.LATC3
#define SCL_PORT                 PORTCbits.RC3
#define SCL_WPU                  WPUCbits.WPUC3
#define SCL_OD                   ODCONCbits.ODCC3
#define SCL_ANS                  ANSELCbits.ANSELC3
#define SCL_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define SCL_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define SCL_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define SCL_GetValue()           PORTCbits.RC3
#define SCL_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define SCL_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define SCL_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define SCL_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define SCL_SetPushPull()        do { ODCONCbits.ODCC3 = 0; } while(0)
#define SCL_SetOpenDrain()       do { ODCONCbits.ODCC3 = 1; } while(0)
#define SCL_SetAnalogMode()      do { ANSELCbits.ANSELC3 = 1; } while(0)
#define SCL_SetDigitalMode()     do { ANSELCbits.ANSELC3 = 0; } while(0)

// get/set RC4 aliases
#define SDA_TRIS                 TRISCbits.TRISC4
#define SDA_LAT                  LATCbits.LATC4
#define SDA_PORT                 PORTCbits.RC4
#define SDA_WPU                  WPUCbits.WPUC4
#define SDA_OD                   ODCONCbits.ODCC4
#define SDA_ANS                  ANSELCbits.ANSELC4
#define SDA_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define SDA_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define SDA_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define SDA_GetValue()           PORTCbits.RC4
#define SDA_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define SDA_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define SDA_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define SDA_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define SDA_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define SDA_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define SDA_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define SDA_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define SW_TRIS                 TRISCbits.TRISC5
#define SW_LAT                  LATCbits.LATC5
#define SW_PORT                 PORTCbits.RC5
#define SW_WPU                  WPUCbits.WPUC5
#define SW_OD                   ODCONCbits.ODCC5
#define SW_ANS                  ANSELCbits.ANSELC5
#define SW_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define SW_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define SW_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define SW_GetValue()           PORTCbits.RC5
#define SW_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define SW_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define SW_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define SW_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define SW_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define SW_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define SW_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define SW_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)
#define RC5_SetInterruptHandler  SW_SetInterruptHandler

// get/set RC6 aliases
#define Tx_TRIS                 TRISCbits.TRISC6
#define Tx_LAT                  LATCbits.LATC6
#define Tx_PORT                 PORTCbits.RC6
#define Tx_WPU                  WPUCbits.WPUC6
#define Tx_OD                   ODCONCbits.ODCC6
#define Tx_ANS                  ANSELCbits.ANSELC6
#define Tx_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define Tx_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define Tx_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define Tx_GetValue()           PORTCbits.RC6
#define Tx_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define Tx_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define Tx_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define Tx_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define Tx_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define Tx_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define Tx_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define Tx_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)
#define RC6_SetInterruptHandler  Tx_SetInterruptHandler

// get/set RC7 aliases
#define Rx_TRIS                 TRISCbits.TRISC7
#define Rx_LAT                  LATCbits.LATC7
#define Rx_PORT                 PORTCbits.RC7
#define Rx_WPU                  WPUCbits.WPUC7
#define Rx_OD                   ODCONCbits.ODCC7
#define Rx_ANS                  ANSELCbits.ANSELC7
#define Rx_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define Rx_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define Rx_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define Rx_GetValue()           PORTCbits.RC7
#define Rx_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define Rx_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define Rx_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define Rx_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define Rx_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define Rx_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define Rx_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define Rx_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)
#define RC7_SetInterruptHandler  Rx_SetInterruptHandler

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the SW pin functionality
 * @param none
 * @return none
 */
void SW_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for SW pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for SW at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void SW_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for SW pin.
 *        This is a dynamic interrupt handler to be used together with the SW_SetInterruptHandler() method.
 *        This handler is called every time the SW ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*SW_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for SW pin. 
 *        This is a predefined interrupt handler to be used together with the SW_SetInterruptHandler() method.
 *        This handler is called every time the SW ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void SW_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the Tx pin functionality
 * @param none
 * @return none
 */
void Tx_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for Tx pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for Tx at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void Tx_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for Tx pin.
 *        This is a dynamic interrupt handler to be used together with the Tx_SetInterruptHandler() method.
 *        This handler is called every time the Tx ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*Tx_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for Tx pin. 
 *        This is a predefined interrupt handler to be used together with the Tx_SetInterruptHandler() method.
 *        This handler is called every time the Tx ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void Tx_DefaultInterruptHandler(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handler for the Rx pin functionality
 * @param none
 * @return none
 */
void Rx_ISR(void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt Handler Setter for Rx pin interrupt-on-change functionality.
 *        Allows selecting an interrupt handler for Rx at application runtime
 * @pre Pins intializer called
 * @param InterruptHandler function pointer.
 * @return none
 */
void Rx_SetInterruptHandler(void (* InterruptHandler)(void));

/**
 * @ingroup  pinsdriver
 * @brief Dynamic Interrupt Handler for Rx pin.
 *        This is a dynamic interrupt handler to be used together with the Rx_SetInterruptHandler() method.
 *        This handler is called every time the Rx ISR is executed and allows any function to be registered at runtime.
 * @pre Pins intializer called
 * @param none
 * @return none
 */
extern void (*Rx_InterruptHandler)(void);

/**
 * @ingroup  pinsdriver
 * @brief Default Interrupt Handler for Rx pin. 
 *        This is a predefined interrupt handler to be used together with the Rx_SetInterruptHandler() method.
 *        This handler is called every time the Rx ISR is executed. 
 * @pre Pins intializer called
 * @param none
 * @return none
 */
void Rx_DefaultInterruptHandler(void);


#endif // PINS_H
/**
 End of File
*/